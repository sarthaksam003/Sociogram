export const TrendData= [
  {
    name: "Ram Mandir",
    shares: 240,
  },
  {
    name: "Don3",
    shares: 80.5,
  },
  {
    name: "CDAC",
    shares: 75.5,
  },
  {
    name: "Reactjs",
    shares: 72,
  },
  {
    name: "Elon Musk",
    shares: 71.9,
  },
  {
    name: "UPpolicepaperleak",
    shares: 636,
  },
];
